# LootDrop Gaming Website

Open `index.html` in a browser to preview the site.

To publish it, upload `index.html` to a static website host such as GitHub Pages, Netlify, or Cloudflare Pages.

Replace the placeholder YouTube/TikTok/Twitch links with your real links.
